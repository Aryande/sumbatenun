<?php if (isset($component)) { $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $attributes; } ?>
<?php $component = App\View\Components\PenggunaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pengguna-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PenggunaLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-light py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-0"><a href="<?php echo e(route('dashboard')); ?>">Home</a> <span class="mx-2 mb-0">/</span>
                    <strong class="text-black">Tentang Kami</strong>
                </div>
            </div>
        </div>
    </div>
    <div class="site-section">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="site-section-heading pt-3 mb-4">
                        <h2 class="text-black">Tentang Kami</h2>
                    </div>
                    <p>
                        Toko_Tenun Sumba merupakan penyedia berbagai jenis kain Tenun yang berasal dari sumba dan di tenun
                        seraca tradisional.

                        Di toko kami, Anda dapat menemukan berbagai jenis kain tenun, mulai dari kain tenun ikat,
                        sarung,dan selempang. Kami juga menyediakan layanan pengiriman lewat kantor pos.
                    
                    </p>
                </div>
                <div class="col-md-5 ml-auto">
                    <div class="p-4 border mb-3">
                        <span class="d-block text-primary h6 text-uppercase">INDONESIA</span>
                        <p class="mb-0">jln Obarade,Kota Elopada, Kec. Wewewa Timur, Kabupaten
                            Sumba Barat Daya</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $attributes = $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $component = $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php /**PATH D:\skripsi\toko_tenun_sumba\resources\views/pengguna/tentangkami.blade.php ENDPATH**/ ?>