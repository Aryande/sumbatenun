<?php if (isset($component)) { $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $attributes; } ?>
<?php $component = App\View\Components\PenggunaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pengguna-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PenggunaLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="site-blocks-cover"
        style="background-image:url(<?php echo e(asset('pengguna/images/bg.jpg')); ?>);" data-aos="fade">
        <div class="container">
            <div class="row align-items-start align-items-md-center justify-content-end">
                <div class="col-md-5 text-center text-md-left pt-5 pt-md-0" style=" background: rgb(78, 31, 219)">
                    <h1 class="mb-2  text-white">Koleksi Produk Tenun</h1>
                    <div class="intro-text text-center text-md-left">
                        <p class="mb-4 text-white">TEMUKAN PRODUK KESUKANAAN KAMU</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="site-section block-3 site-blocks-2 bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-7 site-section-heading text-center pt-4">
                    <h2>Produk Teratas </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="nonloop-block-3 owl-carousel">
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="block-4 text-center">
                                    <figure class="block-4-image">
                                        <img src="<?php echo e($produk->foto); ?>" alt="Image placeholder" class="img-fluid"
                                            height="100">
                                    </figure>
                                    <div class="block-4-text p-4">
                                        <h3><a href="<?php echo e(route('katalog.show', $produk)); ?>"><?php echo e($produk->namaproduk); ?></a>
                                        </h3>
                                        <p class="text-primary font-weight-bold"><?php echo e($produk->harga); ?></p>
                                        <p class="mb-0">Stok Tersedia : <?php echo e($produk->stok); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $attributes = $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $component = $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php /**PATH D:\skripsi\toko_tenun_sumba\resources\views/pengguna/index.blade.php ENDPATH**/ ?>