<?php if (isset($component)) { $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $attributes; } ?>
<?php $component = App\View\Components\PenggunaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pengguna-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PenggunaLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-light py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-0"><a href="<?php echo e(route('dashboard')); ?>">Home</a> <span class="mx-2 mb-0">/</span>
                    <strong class="text-black">Katalog Produk</strong>
                </div>
            </div>
        </div>
    </div>
    <div class="site-section">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-12 order-2">
                    <div class="row">
                        <div class="col-md-12 mb-5">
                            <div class="float-md-left mb-4">
                                <h2 class="text-black h5">Semua Katalog</h2>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-6 col-lg-4 mb-4" data-aos="fade-up">
                                <div class="block-4 text-center border">
                                    <figure class="block-4-image">
                                        <a href="<?php echo e(route('katalog.show', $produk)); ?>"><img src="<?php echo e($produk->foto); ?>"
                                                alt="Image placeholder" class="img-fluid"></a>
                                    </figure>
                                    <div class="block-4-text p-4">
                                        <h3><a href="<?php echo e(route('katalog.show', $produk)); ?>"><?php echo e($produk->namaproduk); ?>

                                            </a>
                                        </h3>
                                        <p class="text-primary font-weight-bold"><?php echo e($produk->harga); ?></p>
                                        <p class="mb-0">Tersedia <?php echo e($produk->stok); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>


        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $attributes = $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $component = $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php /**PATH D:\skripsi\toko_tenun_sumba\resources\views/pengguna/katalog.blade.php ENDPATH**/ ?>