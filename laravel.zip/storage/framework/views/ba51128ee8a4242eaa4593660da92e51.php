<?php if (isset($component)) { $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5 = $attributes; } ?>
<?php $component = App\View\Components\PenggunaLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pengguna-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PenggunaLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="bg-light py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-12 mb-0"><a href="<?php echo e(route('dashboard')); ?>">Home</a> <span class="mx-2 mb-0">/</span>
                    <strong class="text-black">Cart</strong>
                </div>
            </div>
        </div>
    </div>

    <div class="site-section">
        <div class="container">
            <div class="row mb-5">
                <div class="col-8" method="post">
                    <?php if(session('status')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>

                                <th class="product-name">Produk</th>
                                <th class="product-price">Harga</th>
                                <th class="product-quantity">Jumlah</th>
                                <th class="product-total">Total</th>
                                <th class="product-remove">Hapus</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="product-name">
                                        <a href="katalog/<?php echo e($id); ?>">
                                            <h2 class="h5 text-black"><?php echo e($item['name']); ?></h2>
                                        </a>
                                    </td>
                                    <td>RP <?php echo e(number_format($item['harga'])); ?></td>
                                    <td><?php echo e($item['jumlah']); ?></td>
                                    <td>Rp <?php echo e(number_format($item['jumlah'] * $item['harga'])); ?></td>
                                    <td><a href="<?php echo e(route('keranjang.hapus', $id)); ?>"
                                            class="btn btn-primary btn-sm">X</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td>Keranjang Masih Kosong</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row mb-5">
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('katalog')); ?>"
                                        class="btn btn-outline-primary btn-sm btn-block">Cari
                                        Produk Lain </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="row">
                        <div class="col-md-6">
                            <h3 class="text-black">Total bayar</h3>
                        </div>
                        <div class="col-md-6">
                            <h3 class="text-black">Rp. <?php echo e(number_format($totalBayar)); ?></h3>
                        </div>
                        <?php if($totalBayar > 0): ?>
                            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary btn-sm pl-3 btn-block">Order</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $attributes = $__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__attributesOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5)): ?>
<?php $component = $__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5; ?>
<?php unset($__componentOriginale23d7ac4ae3ce9b9ee9a7beaf8dc32e5); ?>
<?php endif; ?>
<?php /**PATH D:\skripsi\toko_tenun_sumba\resources\views/pengguna/keranjang.blade.php ENDPATH**/ ?>